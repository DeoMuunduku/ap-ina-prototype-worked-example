# DataCard — BugAda Cards (Étape 1, PROPRE)

- **Généré** : 2025-11-06T12:27:32+00:00
- **Source** : Bugzilla@Mozilla (BMO) — https://bugzilla.mozilla.org
- **Date d'accès** : 2025-11-05
- **SHA256 entrée** : sha256:1e1b69f5199dc34eaa6a7c34ac6d4408a89c205be0dc6904dab897835024b570
- **Nombre de cartes** : 200
- **Leakage rate (QC)** : 0.37
- **% desc_blob vides** : 1.0
- **Systèmes** : {'bugzilla': 200}
- **Licence** : Mozilla Websites & Communications Terms of Use (voir mentions sur le site)  (https://www.mozilla.org/en-US/about/legal/terms/mozilla/)

## Politique anti-leakage
- Toute feature post-hoc (`status_current`, `resolution`) est **exclue** des features.
- Publication d’une **liste blanche** : `feature_allowlist.txt`.

## QC
- `missingness.csv` (taux de champs manquants ; figure jointe).
- `duplicates.csv` (doublons exacts par `raw_sha256`) — politique: *keep-first*.

## Figures pour papier
- `fig_summary_len_hist.png`
- `fig_created_months.png`
- `fig_components_top10.png`
- `fig_missingness.png`
- `fig_leakage_rules.png`

## Note
Si `desc_blob` est vide dans la source, les modèles en aval se contenteront du **titre** + métadonnées *non post-hoc*. C’est attendu et documenté.
