# AP-InA (BugAda) — Rapport court (τ=0.45)

## Décision τ
- Choix: **tau = 0.45** (issu du sweep HOLDOUT-H)

## Résultats DEV (tau fixé)
- episodes: 157
- abstention_count: 24
- abstention_rate: 0.1529
- latency_ms_p50: 1
- latency_ms_p95: 3.0
- p_top_p50: 0.9048014293851069
- p_top_p95: 1.0
- tau: 0.45
- temperature: 0.2

## Résultats HOLDOUT-H (tau fixé)
- episodes: 43
- abstention_count: 10
- abstention_rate: 0.2326
- latency_ms_p50: 1
- latency_ms_p95: 3.0
- p_top_p50: 0.9048014293851069
- p_top_p95: 1.0
- tau: 0.45
- temperature: 0.2

## Figures
- Coverage vs tau: fig_coverage_vs_tau.png
- Abstention vs tau: fig_abstention_vs_tau.png

## Fichiers livrés
- DEV: traces/, prov/, metrics.json, decision_distribution.csv, indicators.csv
- HOLDOUT-H: traces/, prov/, metrics.json, decision_distribution.csv, indicators.csv
